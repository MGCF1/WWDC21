
import UIKit
import PlaygroundSupport
import SwiftUI

class PreviewGenerator: MandelbrotGenerator{
    
    var zoomReferenceLines : [Line]  = []
    
    var colorScheme : ColorScheme
    
    init(device: iOSDevice, colorScheme : ColorScheme){
        
        let width : Int = 500
        let height : Int = Int(Double(width) * device.aspectRatio)
        
        let unitWidth = 2.4
        
        let unitHeight = unitWidth * device.aspectRatio
        
        self.colorScheme = colorScheme
        
        super.init(device: device, 
                   height: height, 
                   width: width, 
                   xAxis: ( -unitWidth/2.0, unitWidth/2.0 ), 
                   yAxis: ( -unitHeight/2.0 , unitHeight/2.0 )
        )
    }
    
    override func colorFor(x: Int, y: Int) -> UIColor{
        
        let trueX = self.trueX(Double(x))
        let trueY = self.trueY(Double(y))
        
        let value = Mandelbrot.valueFor(c: Complex(-trueY, trueX), numIterations: numIterations)
        
        return colorScheme.colorFor(value: value)
        
        return abs(value) == 1 ? .black : .white
    }
    
    func drawMandelbrot(){
        print("Drawing preview set")
        
        for yVal in 0 ... height {
            for xVal in 0 ... width {
                
                let color = self.colorFor(x: xVal, y: yVal)
                    
                let path = UIBezierPath(rect: CGRect(x: xVal, y: yVal, width: 1, height: 1))
                        
                
                color.set()
                        
                path.fill()
                
                }
            }
        
        print("Completed preview set")
            
    }
    
    func drawLine(x: Double, y: Double){
        
        var line : Line
        
        if(zoomReferenceLines.count < 2){
            
            line = Line(frame: self.frame, x: x)
            
        } else {
            
            line = Line(frame: self.frame, y: y)
            
            let width = zoomReferenceLines[1].x! - zoomReferenceLines[0].x!
            
            let height = width * device.aspectRatio
            
            let bottomLine = Line(frame: self.frame, y: y + height)
            
            zoomReferenceLines.append(bottomLine)
            addSubview(bottomLine)
            
        }
        
        addSubview(line)
        zoomReferenceLines.append(line)
        
    }
    
    
    func updateAxis(){
        
        if(zoomReferenceLines.count < 3){
            return 
            
        }
        
        let left : Double = trueX(zoomReferenceLines[0].x!)
        let right : Double = trueX(zoomReferenceLines[1].x!)
        let bottom : Double = trueY(zoomReferenceLines[2].y!)
        let top : Double = trueY(zoomReferenceLines[3].y!)
        
        let width = right - left
        let height = width * device.aspectRatio
        
        xAxis = (left, right)
        yAxis = (top, bottom)
        
        self.numIterations = Int((2.0 / Double(right - left)) * 100.0)
        
        for line in zoomReferenceLines {
            line.removeFromSuperview()
        }
        
        zoomReferenceLines = []
        self.setNeedsDisplay()
//          self.drawMandelbrot()
        
    }
    
    func handleTap(x: Double, y: Double) -> Bool{
        
        if( zoomReferenceLines.count < 4 ){
            drawLine(x: x, y: y)
            return false
        } else {
            updateAxis()
            return true
        }
    }
    
    override func draw(_ rect: CGRect) {
        drawMandelbrot()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

class Line : UIView {
    
    let x : Double?
    let y : Double?
    
    override init(frame: CGRect){
        self.x = nil
        self.y = nil
        
        super.init(frame: frame)
    }
    
    init(frame: CGRect, x: Double){
        self.x = x
//          super.init(frame: frame)
        self.y = nil
        
        super.init(frame: CGRect(x: 0, y: 0, width: frame.width, height: frame.height))
        
        self.backgroundColor = UIColor.init(white: 0.0, alpha: 0.0)
        
    }
    
    init(frame: CGRect, y: Double){
        self.y = y
        //          super.init(frame: frame)
        self.x = nil
        
        super.init(frame: CGRect(x: 0, y: 0, width: frame.width, height: frame.height))
        
        self.backgroundColor = UIColor.init(white: 0.0, alpha: 0.0)
        
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func draw(_ rect: CGRect){
        
        if let context = UIGraphicsGetCurrentContext(){
            context.setStrokeColor(UIColor.white.cgColor)
            context.setLineWidth(2)
            context.beginPath()
            if let xCord : Double = x {
                context.move(to: CGPoint(x: xCord, y: 0))
                context.addLine(to: CGPoint(x: xCord, y: Double(rect.height)))
            }
            if let yCord : Double = y {
                context.move(to: CGPoint(x: 0, y: yCord))
                context.addLine(to: CGPoint(x: Double(rect.width), y: yCord))
            }
            context.strokePath()
        }
        
    }
    
    
}
