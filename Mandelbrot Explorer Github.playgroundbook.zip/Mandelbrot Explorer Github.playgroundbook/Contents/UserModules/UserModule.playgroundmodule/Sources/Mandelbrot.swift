
public struct Mandelbrot {
    
    public static func iterate(z: inout Complex, c: Complex){
        z = (z * z) + c
    }
    
    static func optimizedIterate(z: inout Complex, c: Complex){
        let y = (z.real + z.real) * z.imaginary + c.imaginary
        let x = z.real - z.imaginary + c.real
        
        z = Complex(x, y)
    }
    
    //29 seconds
    static func optimizedValue(c: Complex) -> Double {
        
//          var z = Complex(0,0)
        var iterationNum = 0
        var x = 0.0
        var y = 0.0
        
        while(iterationNum < 1000){
            let xTemp = x * x - y * y + c.real
            y = 2 * x * y + c.imaginary
            x = xTemp
            
            if(x * x + y*y > 4){
                return 1
            }
            
            iterationNum += 1
            
            
        }
        
        return 0
    }
    
    static func optimizedValue2(c: Complex) -> Double {
        
        //          var z = Complex(0,0)
        var iterationNum = 0
        var x2 = 0.0
        var y2 = 0.0
        var w = 0.0
        
        while(iterationNum < 1000){
            let x = x2 - y2 + c.real
            let y = w - x2 - y2 + c.imaginary
            
            x2 = x * x
            y2 = y * y
            
            w = (x + y) * (x + y)
            
            if(x2 + y2 > 4){
                return 1
            }
            
            iterationNum += 1
            
        }
        return 0
    }
    
    static func optimizedValue3(c: Complex, numIterations: Int) -> Double {
        
        //          var z = Complex(0,0)
        var iterationNum = 0
        var x2 = 0.0
        var y2 = 0.0
        var x = 0.0
        var y = 0.0
        var w = 0.0
        
        while(iterationNum < numIterations){
            
            y = (x + x) * y + c.imaginary
            x = x2 - y2 + c.real
            
            x2 = x * x
            y2 = y * y
            
            if(x2 + y2 > 4){
                return min(Double(iterationNum  ) / Double(numIterations) , 1.0)
            }
            
            iterationNum += 1
            
        }
        return -1
    }
    
    static func valueFor(c: Complex, numIterations: Int) -> Double{
        
        return optimizedValue3(c: c, numIterations: numIterations)
        
//          var z = Complex(0,0)
//          var iterationNum = 0
//          
//          while(iterationNum < 1000){
//              optimizedIterate(z: &z, c: c)
//              
//              if(z.size() > 2){ return Double(iterationNum) / 50 }
//              iterationNum += 1
//          }
//          return 0.0
    }
    
}
