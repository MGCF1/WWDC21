import UIKit
import PlaygroundSupport

public class MandelbrotView: UIViewController {
    
    var preview : PreviewGenerator
    var wallpaper : WallpaperGenerator
    
    var colorScheme : ColorScheme
    
    var instructions : UILabel = UILabel()
    
    var saveButton : UIButton = UIButton()
    
    public init(device: iOSDevice, colorScheme: ColorScheme) {
        
        self.preview = PreviewGenerator(device: device, colorScheme: colorScheme)
        self.wallpaper = WallpaperGenerator(device: device, colorScheme: colorScheme)
        
        self.colorScheme = colorScheme
        
        instructions.text = "These are your instructions."
        
        super.init(nibName: nil, bundle: nil)
        view.backgroundColor = .systemBackground
        
        view.addSubview(preview)
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(setTapped(sender:)))
        
        preview.addGestureRecognizer(tap)
        
        self.instructions.text = "Select the left edge of\nyour zoom window."
        self.instructions.textAlignment = .center
        self.instructions.textColor = .white
        instructions.frame = CGRect(x: 0, y: 0, width: 300, height: 60)
        instructions.backgroundColor = .secondaryLabel
        instructions.numberOfLines = 2
        instructions.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(instructions)
        
        NSLayoutConstraint.activate(
            [
                instructions.widthAnchor.constraint(equalToConstant: 300.0),
                instructions.heightAnchor.constraint(equalToConstant: 60.0),
                instructions.topAnchor.constraint(equalTo: view.topAnchor, constant: 100),
                instructions.centerXAnchor.constraint(equalTo: view.centerXAnchor)
            ]
        )
        
//          let saveButton = UIButton()
        saveButton.backgroundColor = .secondaryLabel
        saveButton.frame = CGRect(x: 0, y: 0, width: 300, height: 60)
        saveButton.setTitle("Save\n(may take a moment)", for: .normal)
        saveButton.titleLabel?.numberOfLines = 2
        saveButton.titleLabel?.textAlignment = .center
        saveButton.translatesAutoresizingMaskIntoConstraints = false
        saveButton.addTarget(self, action: #selector(saveImages), for: .touchUpInside)
        view.addSubview(saveButton)
        
        NSLayoutConstraint.activate(
            [
                saveButton.widthAnchor.constraint(equalToConstant: 300.0),
                saveButton.heightAnchor.constraint(equalToConstant: 60.0),
                saveButton.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -25),
                saveButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -25)])
    }
    
    @objc func setTapped(sender: UITapGestureRecognizer){
        
        let x = sender.location(in: sender.view).x
        let y = sender.location(in: sender.view).y
        
        self.instructions.text = "Zooming..."
        
        DispatchQueue.global(qos: .userInitiated).async {
            DispatchQueue.main.async {
                if( self.preview.handleTap(x: Double(x), y: Double(y)) ) {
                    self.wallpaper.updateAxisTo(self.preview)
                    self.instructions.text = "Select the left edge of\nyour zoom window."
                }
                
                if(self.preview.zoomReferenceLines.count == 1){
                    self.instructions.text = "Select the right edge of\nyour zoom window."
                }
                
                if(self.preview.zoomReferenceLines.count == 2){
                    self.instructions.text = "Select the top edge of\nyour zoom window."
                }
                
                if(self.preview.zoomReferenceLines.count == 4){
                    self.instructions.text = "Click again to confirm."
                }
            }
        }
        

    }
    
    
    
    @objc func handleTap(sender: UITapGestureRecognizer) {
        self.instructions.text = "Tap recognized..."
    }
    
    override public func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        preview.center = CGPoint(x: view.bounds.midX, y: view.bounds.midY)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    public func saveImage() {
        // noop
    }
    
    @objc public func saveImages() {
        
        saveButton.setTitle("Saving...", for: .normal)
        
        DispatchQueue.global(qos: .userInitiated).async {
            self.wallpaper.saveImage()
            
            DispatchQueue.main.async {
                self.saveButton.setTitle("Save\n(may take a moment)", for: .normal)
            }
        }
    }
    
}
