import UIKit
import PlaygroundSupport

class MandelbrotGenerator : UIView {
    public var context = UIGraphicsGetCurrentContext()
    
    let height : Int
    let width : Int
    
    let device : iOSDevice
    
    var xAxis : (Double, Double)
    
    var yAxis : (Double, Double)
    
    var numIterations : Int = 100
    
    init(device: iOSDevice, height: Int, width: Int, xAxis: (Double, Double), yAxis: (Double,Double)){
        
        self.device = device
        self.height = height
        self.width = width
        self.xAxis = xAxis
        self.yAxis = yAxis
        
        super.init(frame: CGRect(x: 0, y: 0, width: width, height: height))
        
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func trueX(_ x: Double) -> Double{
        
        let xRange = xAxis.1 - xAxis.0
        
        let xStep = xRange / Double(width)
        
        return (Double(x) * Double(xStep)) + xAxis.0
        
    }
    
    func trueY(_ y: Double) -> Double{
        
        let yRange = yAxis.1 - yAxis.0
        
        let yStep = yRange / Double(height)
        
        return (Double(y) * Double(yStep)) + yAxis.0
        
    }
    
    func colorFor(x: Int, y: Int) -> UIColor{
        
        let trueX = self.trueX(Double(x))
        let trueY = self.trueY(Double(y))
        
        return UIColor(
            red: 0.0,
            green: 0.0,
            blue: 
                CGFloat(
                    Mandelbrot
                        .valueFor(
                            c: Complex(-trueY, trueX),
                            numIterations: numIterations
                        )
                ),
            alpha: 1.0
        )
    }
}
