//  /*
//  See LICENSE folder for this sample’s licensing information.
//  
//  Abstract:
//  The file to create the pixel art turtle.
//  */
//  import UIKit
//  import PlaygroundSupport
//  import SwiftUI
//  
//  class GridView: UIView {
//      public var context = UIGraphicsGetCurrentContext()
//      
//      let width: Int
//      let height: Int
//      
//      let device : iOSDevice
//      
//      var xAxis : (Double, Double) = (-10.0,10.0)
//      
//      var yAxis : (Double, Double) = (-10.0,10.0)
//      
//      var image: UIImage?
//  
//      init(device: iOSDevice, unitWidth: Double){
//          self.width = device.size.0
//          self.height = device.size.1
//          
//          let unitHeight =  unitWidth * device.aspectRatio
//          
//          xAxis = (-unitWidth/2.0, unitWidth/2.0)
//          
//          yAxis = (-unitHeight/2.0, unitHeight/2.0)
//          
//          self.device = device
//          super.init(frame: CGRect(x: 0, y: 0, width: width, height: height))
//      }
//      
//      
//      init(device: iOSDevice, top : Double, left: Double , right : Double){
//          self.width = device.size.0
//          self.height = device.size.1
//          
//          self.device = device
//          super.init(frame: CGRect(x: 0, y: 0, width: width, height: height))
//      }
//      
//      required init?(coder: NSCoder) {
//          fatalError("init(coder:) has not been implemented")
//      }
//      
//  
//      override func draw(_ rect: CGRect) {
//          drawMandelbrot()
//      }
//      
//      func drawMandelbrot(){
//          //This should be a scaled down version of the view
//          print("Drawing preview set")
//          
//          
//          let previewWidth = 250.0
//          let previewHeight = Int(previewWidth * device.aspectRatio)
//          
//          
//          let scale = 2
//          
//          for xVal in stride(from: 0, to: device.size.0, by: scale) {
//              
//              for yVal in stride(from: 0, to: device.size.1, by: scale) {
//                  
//                  let color = colorFor(x: xVal, y: yVal)
//                  
//                  let path = UIBezierPath(rect: CGRect(x: xVal, y: yVal, width: scale, height: scale))
//                  
//                  color.set()
//                  path.fill()
//                  
//              }
//          }
//          
//          print("Completed preview set")
//      }
//      
//      func draw(context: CGContext?){
//          guard let context = context else {
//              return
//          }
//          
//          context.setLineWidth(1)
//          
//          var xPos: CGFloat = 0
//          var yPos: CGFloat = -(1.0 / 2.0)
//          
//          for yVal in 0 ..< device.size.1 {
//              yPos += 1
//              for xVal in 0 ..< device.size.0 {
//                  
//                  let color = colorFor(x: xVal, y: yVal)
//                  
//                  context.setStrokeColor(color.cgColor)
//                  context.beginPath()
//                  context.move(to: CGPoint(x: xPos, y: yPos))
//                  xPos += 1
//                  
//                  context.addLine(to: CGPoint(x: xPos, y: yPos))
//                  context.strokePath()
//                  
//              }
//              xPos = 0
//          }
//          
//          self.image = UIGraphicsGetImageFromCurrentImageContext()
//          UIGraphicsEndImageContext()
//      }
//      
//      public func saveImage() {
//          print("Generating image...")
//          
//          UIGraphicsBeginImageContext(bounds.size)
//          
//          draw(context: UIGraphicsGetCurrentContext())
//          
//          guard let image = image else { return }
//          
//          print("Saving image...")
//          UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
//          print("Saved...")
//      }
//      
//      func colorFor(x: Int, y: Int) -> UIColor{
//          
//          //x pixel range : 0 -> width
//          //should be     : xAxis.0 -> xAxis.1
//          //y pixel rane  : 0 -> height
//          //should be     : yAxis.0 -> yAxis.1
//          
//          let xRange = xAxis.1 - xAxis.0
//          let xStep = xRange / Double(width)
//          
//          
//          let yRange = yAxis.1 - yAxis.0
//          let yStep = yRange / Double(height)
//          
//          let trueX = (Double(x) * Double(xStep)) + xAxis.0
//          let trueY = (Double(y) * Double(yStep)) + yAxis.0
//          
//          
//          return UIColor(
//              red: 
//                  CGFloat(
//                      Mandlebrot
//                          .valueFor(
//                              c: Complex(-trueY,trueX),
//                              numI
//                              )
//                  ),
//              green: 0.0,
//              blue: 0.0,
//              alpha: 1.0)
//          
//          return UIColor(red: 1.0 - CGFloat(Double(trueX * trueX + trueY * trueY)/Double(10)) , green: 0, blue: 0, alpha: 1)
//          
//          return (trueX * trueX + trueY * trueY < 5) ? UIColor.red : UIColor.black
//      }
//  }
//  
//  public class GridViewController: UIViewController {
//  
//      var gridView: GridView
//      
//      
//      public init(device: iOSDevice) {
////          self.gridView = GridView(pixelSize: 1, device: device)
//          self.gridView = GridView(device: device, unitWidth: 2)
//          super.init(nibName: nil, bundle: nil)
//          view.backgroundColor = .systemBackground
//          view.addSubview(gridView)
//  
//          let saveButton = UIButton()
//          saveButton.backgroundColor = .secondaryLabel
//          saveButton.frame = CGRect(x: 0, y: 0, width: 100, height: 30)
//          saveButton.setTitle("Save", for: .normal)
//          saveButton.translatesAutoresizingMaskIntoConstraints = false
//          saveButton.addTarget(self, action: #selector(saveImages), for: .touchUpInside)
//          view.addSubview(saveButton)
//  
//          NSLayoutConstraint.activate([saveButton.widthAnchor.constraint(equalToConstant: 100.0),
//              saveButton.heightAnchor.constraint(equalToConstant: 30.0),
//              saveButton.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -25),
//              saveButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -25)])
//      }
//  
//      override public func viewDidLayoutSubviews() {
//          super.viewDidLayoutSubviews()
//          gridView.center = CGPoint(x: view.bounds.midX, y: view.bounds.midY)
//      }
//  
//      required init?(coder: NSCoder) {
//          fatalError("init(coder:) has not been implemented")
//      }
//      public func saveImage() {
//          // noop
//      }
//  
//      @objc public func saveImages() {
//          gridView.saveImage()
////        colorGrid2.saveImage()
////        colorGrid3.saveImage()
//      }
//      
////    public override var accessibilityLabel: String? {
////        get {
////            return getTurtleDescription()
////        }
////        set { fatalError("You should not be setting this!") }
////    }
//  }
//  
//  
//  