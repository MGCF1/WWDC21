

import UIKit
import PlaygroundSupport
import SwiftUI

class blackAndWhite: MandelbrotGenerator{
    
//      let numIterations : Int 
    
    init(device: iOSDevice, numIterations: Int){
        
        let width : Int = 500
        let height : Int = Int(Double(width) * device.aspectRatio)
        
        let unitWidth = 2.4
        
        let top = -2.0
        
        let unitHeight = unitWidth * device.aspectRatio
        
        super.init(device: device, 
                   height: height, 
                   width: width, 
                   xAxis: ( -unitWidth/2.0, unitWidth/2.0 ), 
                   yAxis: ( top  , top + unitHeight)
        )
        
        self.numIterations = numIterations
    }
    
    override func colorFor(x: Int, y: Int) -> UIColor{
        
        let trueX = self.trueX(Double(x))
        let trueY = self.trueY(Double(y))
        
        let value = Mandelbrot.valueFor(c: Complex(-trueY, trueX), numIterations: numIterations)
        
        return abs(value) == 1 ? .black : .white
    }
    
    func drawMandelbrot(){
        print("Drawing preview set")
        
        for yVal in 0 ... height {
            for xVal in 0 ... width {
                
                let color = self.colorFor(x: xVal, y: yVal)
                
                let path = UIBezierPath(rect: CGRect(x: xVal, y: yVal, width: 1, height: 1))
                
                
                color.set()
                
                path.fill()
                
            }
        }
        
        print("Completed preview set")
        
    }
    
    override func draw(_ rect: CGRect) {
        drawMandelbrot()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

public class BlackAndWhiteView: UIViewController {
    
    var preview : blackAndWhite
    
    public init(device: iOSDevice, numIterations : Int) {
        
        self.preview = blackAndWhite(device: device, numIterations: numIterations)
        
        super.init(nibName: nil, bundle: nil)
        view.backgroundColor = .systemBackground
        
        view.addSubview(preview)
        
    }
    
    override public func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        preview.center = CGPoint(x: view.bounds.midX, y: view.bounds.midY)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    public func saveImage() {
        // noop
    }
    
}
