import UIKit


public enum colorOption {
    
    case fadeIn
    case fadeOut
    case on
    case off
    
    func colorVal(_ value: CGFloat) -> CGFloat{
        switch self{
        case .fadeIn: return value
        case .fadeOut: return 1 - value
        case .off: return 0.0
        case .on: return 1.0
        }
    }
    
}

public enum presetColor {
    
    case blackToWhite
    case whiteToBlack
    case rainbow
    
    
    

}

public class ColorScheme{

    public init(){
        
    }
    
	public var preset : presetColor = .blackToWhite
    
    public var filled = false
    
	public var fill : UIColor?
    
    public var glowMultiplier = 1.0
    
    public var red : colorOption = .off
    public var green : colorOption = .off
    public var blue : colorOption = .off
    
    func colorFor(value: Double) -> UIColor{
        
        let modVal = max(min(1, value * glowMultiplier),-1)
            
        let cgValue = CGFloat(filled ? abs(modVal) : max(modVal,0.0))
        let inverseValue = CGFloat(1-cgValue)
        
        if(fill != nil && cgValue == 1){
            return fill!
        }
        
		if(!(red == .off && green == .off && blue == .off)){
			return UIColor(red: red.colorVal(cgValue),
						   green: green.colorVal(cgValue),
						   blue: blue.colorVal(cgValue),
						   alpha: 1)
		}
            
		switch preset{
		case .blackToWhite:
			return UIColor(red: cgValue, green: cgValue, blue: cgValue, alpha: 1)
		case .whiteToBlack:
				return UIColor(red: inverseValue, green: inverseValue, blue: inverseValue, alpha: 1)
		case .rainbow:
				return UIColor(hue: 0.88 * cgValue, saturation: 1, brightness: 0.5, alpha: 1)
		
		}
		
        
        
        

        
//          
//          func redVaule() -> CGFloat {
//              
//              switch red {
//              
//              case .fadeIn: return cgValue
//              case .fadeOut: return inverseValue
//              case .off: return 0.0
//              case .on: return 1.0
//              }
//              
//          }

        
//          if(blackToWhite){
//              return UIColor(red: cgValue, green: cgValue, blue: cgValue, alpha: 1)
//          } else {
//              return UIColor(red: inverseValue, green: inverseValue, blue: inverseValue, alpha: 1)
//          }
        
//          return UIColor.blue
    }
    
}
