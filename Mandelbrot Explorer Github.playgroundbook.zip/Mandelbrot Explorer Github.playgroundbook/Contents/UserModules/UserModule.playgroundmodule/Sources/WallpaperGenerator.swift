import UIKit
import PlaygroundSupport

class WallpaperGenerator : MandelbrotGenerator{
    
    var colorScheme: ColorScheme
    
    init(device: iOSDevice, colorScheme: ColorScheme){
        
        let unitWidth = 2.4
        
        let unitHeight = unitWidth * device.aspectRatio
        
        self.colorScheme = colorScheme
        
        super.init(device: device, 
                   height: device.size.1, 
                   width: device.size.0, 
                   xAxis: ( -unitWidth/2.0, unitWidth/2.0 ), 
                   yAxis: ( -unitHeight/2.0 , unitHeight/2.0 )
        )
    }
    
    override func colorFor(x: Int, y: Int) -> UIColor{
        
        let trueX = self.trueX(Double(x))
        let trueY = self.trueY(Double(y))
        
        let value = Mandelbrot.valueFor(c: Complex(-trueY, trueX), numIterations: numIterations)
        
        return colorScheme.colorFor(value: value)
    }
    
    func generateImage(context: CGContext?) -> UIImage?{
        
        guard let context = context else {
            return nil
        }
        
        context.setLineWidth(1)
        
        var xPos: CGFloat = 0
        var yPos: CGFloat = -(1.0 / 2.0)
        
        for yVal in 0 ..< device.size.1 {
            yPos += 1
            for xVal in 0 ..< device.size.0 {
                
                let color = colorFor(x: xVal, y: yVal)
                
                context.setStrokeColor(color.cgColor)
                context.beginPath()
                context.move(to: CGPoint(x: xPos, y: yPos))
                xPos += 1
                
                context.addLine(to: CGPoint(x: xPos, y: yPos))
                context.strokePath()
                
            }
            xPos = 0
        }
        
        return UIGraphicsGetImageFromCurrentImageContext()
        
    }
    
    func updateAxisTo(_ preview : PreviewGenerator){
        
        self.xAxis = preview.xAxis
        self.yAxis = preview.yAxis
        
    }
    
    public func saveImage() {
        print("Generating image...")
        
        UIGraphicsBeginImageContext(bounds.size)
        
        guard let image = generateImage(context: UIGraphicsGetCurrentContext()) else {
            return
        }
        
        UIGraphicsEndImageContext()
        
        print("Saving image...")
        UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
        print("Saved...")
        
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
