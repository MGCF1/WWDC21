public enum iOSDevice: String{
    case iPhoneProMax
    case iPhoneXsMax
    
    case iPhone11
    case iPhone12
    case iPhoneXR
    
    case iPhonePro
    case iPhoneXs
    case iPhoneX
    
    case iPhonePlus
    
    case iPhone8
    case iPhone7
    case iPhone6s
    case iPhone6
    
    case iPhoneSE
    
    case iPadPro129
    case iPadPro105
    case iPadPro97
    case iPadAir2
    case iPadMini4
    
    case playgroundCover
    
    var size: (Int,Int){
        
        switch self{
        
        case .iPhoneProMax, .iPhoneXsMax: return(1242,2688)
        case .iPhone11, .iPhone12, .iPhoneXR : return(828, 1792)
        case .iPhonePro, .iPhoneXs, .iPhoneX: return (1125,2436)
        case .iPhonePlus : return (1080,1920)
        case .iPhone8, .iPhone7, .iPhone6s, .iPhone6: return (750, 1334)
        case .iPhoneSE: return (640, 1136)
        case .iPadPro129 : return (2048,2732)
        case .iPadPro105 : return (1668,2224)
        case .iPadPro97, .iPadAir2, .iPadMini4: return (1536,2048)
        case .playgroundCover : return (455, 600)
            
        default: return (100,100)
            
        }
        
    }
    
    var aspectRatio : Double {
        return Double(size.1) / Double(size.0)
    }
}
