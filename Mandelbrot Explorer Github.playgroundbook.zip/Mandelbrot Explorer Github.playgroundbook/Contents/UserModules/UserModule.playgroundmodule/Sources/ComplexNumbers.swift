
public struct Complex : Equatable{
    public var real : Double
    public var imaginary : Double
    
    public init(_ real: Double, _ imaginary: Double){
        self.real = real
        self.imaginary = imaginary
    }
	
	public init(real: Double, imaginary: Double){
		self.real = real
		self.imaginary = imaginary
	}
    
	public init(real: Int, imaginary: Int){
		self.real = Double(real)
		self.imaginary = Double(imaginary)
	}
	
    static func *(_ lhs: Complex, _ rhs: Complex) -> Complex{
        
        return Complex((lhs.real * rhs.real) - (lhs.imaginary * rhs.imaginary), (lhs.real * rhs.imaginary) + (lhs.imaginary * rhs.real)) 
        
    }
    
    static func +(_ lhs: Complex, _ rhs: Complex) -> Complex {
        
        return Complex(lhs.real + rhs.real , lhs.imaginary + rhs.imaginary)
        
    }
    
    public func size() -> Double{
        
        return (real*real + imaginary*imaginary).squareRoot()
        
    }
    
}
