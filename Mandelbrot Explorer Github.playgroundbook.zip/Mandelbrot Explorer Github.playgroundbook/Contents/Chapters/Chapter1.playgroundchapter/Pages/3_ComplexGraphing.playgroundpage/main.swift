//#-code-completion(module, hide, Swift)
//#-code-completion(identifier, hide, _setup(), AbstractPointChartable)
/*:#localized(key: "FirstProseBlock")

# Complex Graphics

Some fun and visual patterns can be created from equations on the complex plane.

One such equation is the recusrsive function

```
Z₁ = Z₀² + C

Z: Starts at 0 + 0i
C: The point that is being checked

```

Lets declare a starting point **C:**

*/
//#-hidden-code
var C = Complex(real: -1.0, imaginary: 0.3)
//#-end-hidden-code
//#-editable-code

C = Complex(real: -1.0, imaginary: 0.3)

//#-end-editable-code
//#-hidden-code
_setup()

var Z = Complex(real: 0, imaginary: 0)

let line = LinePlot(xyData: (-3,-3), (3,3))
line.color = Color.clear

let data = XYData()

data.append(x: C.real, y: C.imaginary)

Mandelbrot.iterate(z: &Z, c: C)

func iterate(){
	
	if(Z.size() <= 2){
		
		Mandelbrot.iterate(z: &Z, c: C)
		
		data.append(x: Z.real, y: Z.imaginary)
		
	}
	
	
}
//#-end-hidden-code
/*:#localized(key: "SecondProseBlock")

I've provided you with a function to iterate once:

```
iterate()
```


Try starting from differnt points be redefining **C**,
and try using a loop to run the iteration multiple times.

```
for _ in 1...10 {

	iterate()

}

If your point escapes the defined bounds (shown in blue), your iterations will stop.
```

*/

//#-editable-code
iterate()

//#-end-editable-code

//#-hidden-code

let lineFromDataSet = LinePlot(xyData: data)


let topCircle = LinePlot(bounds: (-2,2)) { x in
	if( x > -2 && x < 2){
		return (4 - (x * x)).squareRoot()
	} else {
		return 0.0
	}
	
}

let bottomCircle = LinePlot(bounds: (-2,2)) { x in
	if( x > -2 && x < 2){
		return -(4 - (x * x)).squareRoot()
	} else {
		return 0.0
	}
	
}

topCircle.color = Color.blue
bottomCircle.color = Color.blue

//#-end-hidden-code
