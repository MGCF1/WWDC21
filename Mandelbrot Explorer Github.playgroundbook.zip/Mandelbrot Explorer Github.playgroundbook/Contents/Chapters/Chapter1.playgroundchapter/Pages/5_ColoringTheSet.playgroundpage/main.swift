//#-hidden-code
import UIKit
import PlaygroundSupport

var device : iOSDevice = .iPhoneProMax

//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")

# Coloring The Mandelbort Set

There are many advanced methods for adding a splash of color to the mandelbrot set, but the most basic (and the one we will be using today) is based off of the number of iterations it took a point to escape the set.

On the right you see the mandlebrot set colored in gray scaled based off of the number of iterations it took each point to escape.


You can use the color scheme object to customize the Mandelbrot set.
*/

var colorScheme : ColorScheme = ColorScheme()

/*:#localized(key: "SecondProseBlock")

### The colorScheme object has many preset options:
```
colorScheme.preset = .rainbow
colorScheme.preset = .blackToWhite
colorScheme.preset = .whiteToBlack
```

### It also allows for custom coloring:
```
colorScheme.red = .fadeIn
colorScheme.green = .off
colorScheme.blue = .fadeOut
```
*for each of the values red green and blue you can either set them to fade in, fade out, or always be on/off*

### There are a few extra modifiers to further personalize the set:
```
//Adjust the "glow"
colorScheme.glowMultiplier = 3.14

//Manually set the color of the filled set
colorScheme.fill = UIColor.black

//Enable or disable the set's fill
colorScheme.filled = false
```

## Try customizing your own below!

*/
//Uncomment the code below for a quick customization!
//#-editable-code

//  colorScheme.red = .fadeIn
//  colorScheme.blue = .fadeIn
//  colorScheme.glowMultiplier = 3

//#-end-editable-code
//#-hidden-code
let mandelbrotView = ColoredMandelbrotView(device: device, colorScheme: colorScheme)

PlaygroundPage.current.liveView = mandelbrotView
PlaygroundPage.current.needsIndefiniteExecution = true
//#-end-hidden-code
