/*:#localized(key: "FirstProseBlock")

# Mandelbrot Set

The equation described on the last page is known as the Mandelbrot set.

The equation is run for each point *n* times. If Z escapes a circle centered at the origin with a radius of two, it is defined as outside of the set. All other points are considered inside the set.
 

In the demo on the right the points that do not escape are colored in black, and the points colored in white escaped.

You can change the number of times the points are iterated by changing *n*.

*/
//#-hidden-code

import UIKit
import PlaygroundSupport

var device : iOSDevice = .iPhoneProMax

var n : Int = 100
//#-end-hidden-code

//Change n to see how the set is effected

//#-editable-code
n = 100
//#-end-editable-code
//#-hidden-code
let mandelbrotView = BlackAndWhiteView(device: device, numIterations: n)

PlaygroundPage.current.liveView = mandelbrotView
PlaygroundPage.current.needsIndefiniteExecution = true

//#-end-hidden-code
