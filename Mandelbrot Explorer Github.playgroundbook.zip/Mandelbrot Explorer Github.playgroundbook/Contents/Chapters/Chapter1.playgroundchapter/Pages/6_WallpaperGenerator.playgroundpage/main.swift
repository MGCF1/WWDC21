/*:#localized(key: "FirstProseBlock")

# Create a wallpaper!

Now that you've learned how the Mandelbrot set is created, and a few ways to customize it, use this page to create a wallpaper for your device.

You can select your iOS device using:
```
device = .iPhoneSE
```

All of the colorScheme customization options are still avaliable, and you can follow the instructions on the right to zoom into the mandelbrot set!

*Warning: As you zoom in load times will increase.*

**Click save image to generate a wallpaper matching your device's size, depending on your zoom it can take a while to load.**

*/

var colorScheme : ColorScheme = ColorScheme()

//#-hidden-code

import UIKit
import PlaygroundSupport

var device : iOSDevice = .iPhoneProMax

//#-end-hidden-code

//#-editable-code


device = .iPhoneProMax

//  colorScheme.red = .fadeIn
//  colorScheme.blue = .fadeIn
//  colorScheme.glowMultiplier = 3


//#-end-editable-code
//#-hidden-code
let mandelbrotView = MandelbrotView(device: device, colorScheme: colorScheme)

PlaygroundPage.current.liveView = mandelbrotView
PlaygroundPage.current.needsIndefiniteExecution = true
//#-end-hidden-code
