/*:#localized(key: "FirstProseBlock")

# What is a complex number?

A complex number is a combination of both real and imaginary numbers

```
2 + 5i
```

All complex numbers take the pattern of:

*a + bi*

where *a* represent the real part of the number, and *b* the imaginary.

A convenient way to represent this new **complex number** is on a 2D plane.

*This is known as the complex plane*

*/
//#-hidden-code

var C : Complex = Complex(real: 2, imaginary: 5)

//#-end-hidden-code
//Lets try declaring a complex number
//please make both the real and imaginary parts no more than 5

//#-editable-code
C = Complex(real: 2, imaginary: 5)
//#-end-editable-code

/*:#localized(key: "SecondProseBlock")

*run code to see your number on the complex plane.*

*/
//#-hidden-code

let lightBlue : SwiftUI.Color = Color(red: 128.0/255.0, green: 206.0/255.0, blue: 225.0/255.0)

let darkBlue : SwiftUI.Color = Color(red: 8.0/255.0, green: 75.0/255.0, blue: 131.0/255.0)

let lightGray : SwiftUI.Color = Color(red: 211.0/255.0, green: 211.0/255.0, blue: 225.0/255.0)

let red : SwiftUI.Color = Color(red: 255.0/255.0, green: 93.0/255.0, blue: 115.0/255.0)

var interaction = "tap"
var Interaction = "Tap"
#if targetEnvironment(macCatalyst)
interaction = "click"
Interaction = "Click"
#endif

import SwiftUI
import PlaygroundSupport

struct liveView : View{
	
	@State var complexPlane = false
	
	let c : Complex
	
	
	init(_ C: Complex){
		
		self.c = C
		
	}
	
	var body: some View{
		ZStack(){
			
			GeometryReader { geo in
				ball
					.offset(
						x: complexPlane ?
							geo.size.width/2 - 20 :
							geo.size.width/2 - 85 ,
						y: complexPlane ?
							geo.size.height/2 - 31 :
							83
					)
					.offset(
						x: complexPlane ?
							(geo.size.width) / 12 * CGFloat(C.real):
							0,
						y: complexPlane ?
							(geo.size.width) / 12 * CGFloat(-C.imaginary) :
							0

					)
					.zIndex(1)
			}
			
			
			VStack(){

				Text("\(Interaction) to show the complex plane.")
					.multilineTextAlignment(.center)
					.font(Font.largeTitle.weight(.bold))

				ZStack(){
					HStack(){
						if(!complexPlane){
							Text("=")
						}
						Text("\(Int(c.real)) \(c.imaginary >= 0 ? "+" : "-") \(abs(Int(c.imaginary)))i")
					}
						.padding(.top, complexPlane ? 25 : 50)
				}
				.font(Font.title.weight(.bold))
				Spacer()
				convertButton
			}
			.foregroundColor(.black)
			
			dynamicNumberLine
				.rotationEffect(Angle.degrees( complexPlane ? -90 : 0))
				.offset(x: complexPlane ? 11 : 0,
						y: complexPlane ? -11 : 0)
				.foregroundColor(.black)
			
			if(complexPlane){
				numberLine
					.foregroundColor(.black)
			}
			
		}
		.padding(20)
		.background(
			RoundedRectangle(cornerRadius: 40)
				.foregroundColor(Color.white)
				.shadow(radius: 20)
		)
		.padding()
		
		
	}
	
	var ball: some View {
		
		Text("C")
			.font(Font.title3.weight(.bold))
			.frame(width: 40, height: 40)
			.background(
				Circle()
					.foregroundColor(Color.green)
					.shadow(radius: complexPlane ? 10 : 0 )
			)
			.overlay(
				Circle()
					.stroke(Color.black, lineWidth: 2)
			)
		
	}
	
	var dynamicNumberLine: some View {
		ZStack(){
			GeometryReader { geo in
				
				ZStack(){
					
					ForEach(-5...5, id: \.self){ n in
						if(!(n == 0 && complexPlane)){
							ZStack(){
								Capsule()
									.frame(width: 4, height: 20)
								
								ZStack(){
									
									if(!complexPlane){
										Text("\(n)")
									} else {
										Text("\(abs(n) > 1 ? "\(n)" : "")i")
									}
								}
								.rotationEffect(Angle.degrees(complexPlane ? 90 : 0))
								.offset(x: 0,y: 25)
							}
							.offset(x: (geo.size.width / 12 * CGFloat(n)), y: 0)
							.font(Font.title3.weight(.bold))
						}
					}
				}
				.frame(maxWidth: .infinity)
				.background(
					Capsule()
						.frame(height: 4)
				)
			}
		}
		.frame(height: 42)
	}
	
	var convertButton : some View{
		Button(
			action: {
				withAnimation(.spring()){
					complexPlane.toggle()
				}
			}){
			
			Text("Convert")
				.foregroundColor(darkBlue)
				.bold()
				.animation(.none)
				.font(.title)
				.padding()
				.frame(maxWidth: .infinity)
				.background(
					RoundedRectangle(cornerRadius: 20)
						.foregroundColor(lightBlue)
						.shadow(radius: 10)
				)
				.overlay(
					RoundedRectangle(cornerRadius: 20)
						.stroke(darkBlue, lineWidth: 4)
				)
		}
		
	}
	
	var numberLine: some View {
		ZStack(){
			GeometryReader { geo in
				
				ZStack(){
					
					ForEach(-5...5, id: \.self){ n in
						
						if(!(complexPlane && n == 0)){
							ZStack(){
								Capsule()
									.frame(width: 4, height: 20)
								
								Text("\(abs(n))")
									.offset(x: 0, y: 25)
								
								if(n < 0){
									Text("-")
										.offset(x: -10, y: 25)
								}
							}
							.offset(x: (geo.size.width / 12 * CGFloat(n)), y: 0)
							.font(Font.title3.weight(.bold))
						}
					}
				}
				.frame(maxWidth: .infinity)
				.background(
					Capsule()
						.frame(height: 4)
				)
			}
		}
		.frame(height: 42)
	}
}

PlaygroundPage.current.setLiveView(liveView(C))
//#-end-hidden-code

