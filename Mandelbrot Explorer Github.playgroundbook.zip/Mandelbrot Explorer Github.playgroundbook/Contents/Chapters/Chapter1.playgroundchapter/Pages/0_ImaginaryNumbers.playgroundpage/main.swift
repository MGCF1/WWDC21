/*




*/

/*:

 */

/*:#localized(key: "FirstProseBlock")

# What is an imaginary number?

In the set of real numbers there is no defined value for:

*√-1*

(There is no real number in which squaring it produces -1)


To include the concept of *√-1* in mathmatics the symbol:


*i*


was defined as the **imaginary** value of *√-1*.


## Expanding this concept

The base unit *i* can be combined with other numbers to create an entire new number line of imaginary numbers

```
√-25 = √-1 * √25 = i * 5 = 5i
```

*/

//#-editable-code




















//#-end-editable-code





/*:#localized(key: "FirstProseBlock")

# What is a complex number?

A complex number is a combination of both real and imaginary numbers

```
7 + 5i
```

All complex numbers take the pattern of:

*a + bi*

where a represent the real part of the number, and b the imaginary.

A convenient way to represent this new **complex number** is on a 2D plane.

*This is known as the complex plane*

*/


/*:#localized(key: "FirstProseBlock")

# Complex Graphics

Some fun and visual patterns can be created from equations on the complex plane.

One such equation is the recusrsive function

```
Z₁ = Z₀² + C

Z: Starts at 0 + 0i
C: The point that is being checked

```

Lets declare a starting point **C**

*/

//#-hidden-code

var C = Complex(real: 0, imaginary: 0)

//#-end-hidden-code

//#-editable-code

C = Complex(real: 0, imaginary: 0)

//#-end-editable-code


/*:#localized(key: "SecondProseBlock")

I've provided you with a function to iterate once:

```
iterate()
```

Try starting from differnt points be redefining **C**,
and try using a loop to run the iteration multiple times.

*/

//#-editable-code











//#-end-editable-code

/*:#localized(key: "FirstProseBlock")

# Mandlebrot Set

The equation described on the last page is known as the Mandelbrot set.

The equation is run for each point *n* times. If Z escapes a circle centered at the origin with a radius of two, it is defined as outside of the set. All other points are considered inside the set.
 

In the demo on the right the points that do not escape are colored in black, and the points colored in white escaped.

*/


/*:#localized(key: "FirstProseBlock")

# Coloring The Mandelbort Set

There are many advanced methods for adding a splash of colot to the mandelbrot set, but the most basic (and the one we will be using today) is based off of the number of iterations it took a point to escape the set.

On the right you see the mandlebrot set colored in gray scaled based off of the number of iterations it took each point to escape.

*/

//#-hidden-code



//#-end-hidden-code


//#-editable-code



//#-end-editable-code



//#-hidden-code

//#-end-hidden-code

/*



# Text
It's very easy to make some words **bold** and other words *italic* with Markdown. You can even [link to Google!](http://google.com)

# Lists
Sometimes you want numbered lists:

1. One
2. Two
3. Three

Sometimes you want bullet points:

* Start a line with a star
* Profit!

Alternatively,

- Dashes work just as well
- And if you have sub points, put two spaces before the dash or star:
  - Like this
  - And this

# Code
```
if (isAwesome){
  return true
}
```


$\cos$

$\Gamma$

√(-1)
*/
