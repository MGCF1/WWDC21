//#-hidden-code
//111#-editable-code

import PlaygroundSupport
import SwiftUI

let lightBlue : SwiftUI.Color = Color(red: 128.0/255.0, green: 206.0/255.0, blue: 225.0/255.0)

let darkBlue : SwiftUI.Color = Color(red: 8.0/255.0, green: 75.0/255.0, blue: 131.0/255.0)

let lightGray : SwiftUI.Color = Color(red: 211.0/255.0, green: 211.0/255.0, blue: 225.0/255.0)


//let lightGray = Color.lightGray

let red : SwiftUI.Color = Color(red: 255.0/255.0, green: 93.0/255.0, blue: 115.0/255.0)

var interaction = "tap"
var Interaction = "Tap"
#if targetEnvironment(macCatalyst)
interaction = "click"
Interaction = "Click"
#endif

struct Preview: View {
	
	@State var imaginary: Bool = false
	
	var body: some View{
		ZStack(){
			GeometryReader { geo in
				ball
				.offset(
					x:
						imaginary ?
						((geo.size.width) / 12) * 7 - 20:
						((geo.size.width) / 2) - 20,
					y:
						imaginary ?
						geo.size.height/2 - 90 :
						geo.size.height/2 + 80
				)
			}
			.zIndex(1)
							
			VStack(spacing: 20){
				Text("\(Interaction) convert to swap between the real and imaginary numberline.")
					.multilineTextAlignment(.center)
					.font(Font.largeTitle.weight(.bold))
				
				Spacer()
				
				convertButton
				
			}
			
			VStack(spacing: 40){
				Spacer()
				
				Text("\(imaginary ? "Imaginary" : "Real") number line:")
					.padding(.bottom, 40)
					.font(Font.title2.weight(.bold))
					.animation(.none)
				
				
				numberLine2
				
				undefinedSet
				
				Spacer()
			}
		}
		.padding(20)
		.background(
			RoundedRectangle(cornerRadius: 40)
				.foregroundColor(Color.white)
				.shadow(radius: 20)
		)
		.padding()
		.foregroundColor(.black)
	}
	
	
	var ball: some View {
		
		Text("√-1")
			.font(Font.title3.weight(.bold))
			.frame(width: 40, height: 40)
			.background(
				Circle()
					.foregroundColor(imaginary ? Color.green : red)
					.shadow(radius: 10)
			)
			.overlay(
				Circle()
					.stroke(Color.black, lineWidth: 2)
			)
		
	}
	
	var numberLine2: some View {
		
		ZStack(){
			GeometryReader { geo in
				
				ZStack(){
					
					ForEach(-5...5, id: \.self){ n in
						ZStack(){
							Capsule()
								.frame(width: 4, height: 20)
							if(imaginary && abs(n) > 1){
								Text("i")
									.offset(x: 7, y: 25)
							}
							
							if(imaginary && abs(n) == 1){
								Text("i")
									.offset(x: 0, y: 25)
								
							} else {
								Text("\(abs(n))")
									.offset(x: 0, y: 25)
								
							}
							if(n < 0){
								Text("-")
									.offset(x: -10, y: 25)
							}
						}
						.offset(x: (geo.size.width / 12 * CGFloat(n)), y: 0)
						.font(Font.title3.weight(.bold))
					}
				}
				.frame(maxWidth: .infinity)
				.background(
					Capsule()
						.frame(height: 4)
				)
			}
		}
		.frame(height: 42)
		.foregroundColor(.black)
	}
	
	var undefinedSet : some View {
		
		VStack(){
			Text("Undefined:")
				.font(Font.title3.weight(.bold))
				.padding(.top, 10)
			Spacer()
				.frame(height: 75)
			
		}
		.frame(maxWidth: .infinity)
		.background(
			RoundedRectangle(cornerRadius: 10)
				.foregroundColor(red)
		)
		.padding(.horizontal, 50)
		.opacity(imaginary ? 0.0 : 1)
		
	}
	
	var convertButton : some View{
		Button(
			action: {
				withAnimation(.spring()){
					imaginary.toggle()
				}
			}){
			
			Text("Convert")
				.foregroundColor(darkBlue)
				.bold()
				.animation(.none)
				.font(.title)
				.padding()
				.frame(maxWidth: .infinity)
				.background(
					RoundedRectangle(cornerRadius: 20)
						.foregroundColor(lightBlue)
						.shadow(radius: 10)
				)
				.overlay(
					RoundedRectangle(cornerRadius: 20)
						.stroke(darkBlue, lineWidth: 4)
				)
		}
		
	}
}

PlaygroundPage.current.setLiveView(Preview())
//111#-end-editable-code

//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")

# What is an imaginary number?

In the set of real numbers there is no defined value for:

*√-1*

(There is no real number in which squaring it produces -1)


To include the concept of *√-1* in mathmatics the symbol:


*i*


was defined as the **imaginary** value of *√-1*.


## Expanding this concept

The base unit *i* can be combined with other numbers to create an entire new number line of imaginary numbers

```
√-25 = √-1 * √25 = i * 5 = 5i
```

*/
